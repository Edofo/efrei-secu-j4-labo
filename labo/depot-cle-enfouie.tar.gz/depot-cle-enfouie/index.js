// Mini-service météo de démonstration (labo J4).
import { config } from "./config.js";

async function meteo(ville) {
  const url = `https://api.meteo.exemple.test/v1/now?ville=${encodeURIComponent(ville)}&key=${config.apiKey}`;
  const r = await fetch(url);
  return r.json();
}

meteo("Paris").then((d) => console.log(d)).catch(() => console.log("hors ligne (démo)"));
