// Configuration du service.
// La clé est maintenant lue depuis l'environnement (ne jamais la commiter).
export const config = {
  apiKey: process.env.METEO_API_KEY ?? "",
  ville: process.env.METEO_VILLE ?? "Paris",
};
