# Météo Forteresse (démo)

## Lancer
```
cp .env.example .env   # renseignez METEO_API_KEY
npm start
```
